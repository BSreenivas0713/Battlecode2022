package MPCoordinated;

import battlecode.common.*;
import MPCoordinated.Debug.*;
import MPCoordinated.Util.*;

public class Laboratory extends Robot{
    public Laboratory(RobotController r) throws GameActionException {
        super(r);
    }
    public void takeTurn() throws GameActionException {
        super.takeTurn();
    }
    
}
