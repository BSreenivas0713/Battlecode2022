package MPFuture;

import battlecode.common.*;
import MPFuture.Debug.*;
import MPFuture.Util.*;

public class Sage extends Robot{
    public Sage(RobotController r) throws GameActionException {
        super(r);
    }
    public void takeTurn() throws GameActionException {
        super.takeTurn();
    }
}
